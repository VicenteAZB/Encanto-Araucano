<?php
    session_start();
    session_destroy();
    header("location: Encanto%20Araucano.php");
?>