<?php
    $conexion = mysqli_connect("", "", "", "");

    /*if($conexion){
        echo 'Se conectó a la base de datos.';
    }else{
        echo 'No se ha podido conectar a la base de datos.';
    }*/
?>